# Food Quality Inspection System (Machine Vision for Robotics)

Run: `pip install -r requirements.txt`

Train (optional): `python train_classifier.py --data_dir data/classification --epochs 10`

UI: `streamlit run app.py`
