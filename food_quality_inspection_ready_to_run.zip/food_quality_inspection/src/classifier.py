
from __future__ import annotations

import os
from typing import Dict

import numpy as np
import cv2

import torch
import torch.nn as nn
import torchvision.transforms as T


class SmallCNN(nn.Module):
    def __init__(self, num_classes: int = 3):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.classifier = nn.Linear(64, num_classes)

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x


class QualityClassifier:
    def __init__(self, weights_path: str = 'models/quality_classifier.pt', device: str | None = None):
        self.class_names = ['fresh', 'medium', 'rotten']
        if device is None:
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.device = device

        self.model = SmallCNN(num_classes=len(self.class_names)).to(self.device)
        self.model.eval()

        self.transform = T.Compose([
            T.ToTensor(),
            T.Resize((160, 160)),
            T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

        self.is_trained = False
        if os.path.exists(weights_path):
            state = torch.load(weights_path, map_location=self.device)
            self.model.load_state_dict(state)
            self.is_trained = True

    def predict_proba(self, roi_bgr: np.ndarray) -> Dict[str, float]:
        if roi_bgr is None or roi_bgr.size == 0:
            return {'fresh': 0.34, 'medium': 0.33, 'rotten': 0.33}

        img_rgb = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2RGB)
        x = self.transform(img_rgb).unsqueeze(0).to(self.device)

        with torch.no_grad():
            logits = self.model(x)
            probs = torch.softmax(logits, dim=1).cpu().numpy().reshape(-1)

        out = {}
        for i, name in enumerate(self.class_names):
            out[name] = float(probs[i])

        if not self.is_trained:
            out = {k: 1.0 / 3.0 for k in self.class_names}

        return out
